import { Bar, BarChart, CartesianGrid, Cell, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis } from 'recharts';
import { Download } from 'lucide-react';
import { number, plans, project, ratio, type Scenario } from './model';
import type { Neighbourhood, Snapshot } from './types';

const format = (value: unknown) => typeof value === 'number' ? number.format(value) : String(value);

export default function Evidence({ data, scenario, selected, onSelect, download }: {
  data: Snapshot;
  scenario: Scenario;
  selected?: Neighbourhood;
  onSelect: (id: string) => void;
  download: () => void;
}) {
  const all = data.features.map((f) => f.properties);
  const totals = all.reduce((history, area) => history.map((value, i) => value + area.history[i]), Array<number>(7).fill(0));
  const permits = (selected?.history ?? totals).map((net, i) => ({ year: String(2019+i), net }));
  const scenarioRows = [
    { name: 'One-unit reference', homes: all.reduce((sum,n) => sum + project(n, { ...plans.reference.scenario, takeUp: scenario.takeUp, servicing: scenario.servicing }).net, 0) },
    { name: 'HAF-inspired', homes: all.reduce((sum,n) => sum + project(n, { ...plans.haf.scenario, takeUp: scenario.takeUp, servicing: scenario.servicing }).net, 0) },
    { name: 'Six units + transit', homes: all.reduce((sum,n) => sum + project(n, { ...plans.missingMiddle.scenario, takeUp: scenario.takeUp, servicing: scenario.servicing }).net, 0) },
    { name: 'Your scenario', homes: all.reduce((sum,n) => sum + project(n, scenario).net, 0) },
  ].map(x => ({ ...x, homes: Math.round(x.homes) }));
  const top = all.map(n => ({ id: n.id, name: n.name, burden: n.census?.rentBurden, net: Math.round(project(n,scenario).net) }))
    .filter((n): n is typeof n & { burden: number } => n.burden != null)
    .sort((a,b) => b.net - a.net || a.name.localeCompare(b.name))
    .slice(0,15);
  const historicalNet = permits.reduce((sum, p) => sum + p.net, 0);
  const annualised = historicalNet * 10 / 7;
  const ranked = all.map(n => ({ id: n.id, name: n.name, homes: Math.round(project(n,scenario).net) }))
    .filter(n => n.homes > 0).sort((a,b) => b.homes - a.homes || a.name.localeCompare(b.name)).slice(0,15);
  const zoning = all.flatMap(n => {
    const r1 = ratio(n.r1,n.residential);
    const burden = n.census?.rentBurden;
    return r1 == null || burden == null ? [] : [{ r1: Math.round(r1*10)/10, burden,
      population: n.census?.population ?? 0, name: n.name, id: n.id }];
  });
  const hasPositive = top.some(n => n.net > 0);
  function goToArea(id: string) {
    onSelect(id);
    document.querySelector('#simulator')?.scrollIntoView({block:'start'});
  }

  return <section id="evidence" className="shell evidence-section" aria-labelledby="evidence-title">
    <div className="section-heading"><div><div className="eyebrow">Evidence</div>
      <h2 id="evidence-title">What the scenarios reveal</h2></div>
      <button className="button secondary" onClick={download}><Download size={17} />Download scenario CSV</button>
    </div>
    <div className="charts-grid">
      <article className="pane chart-card">
        <h3>Compare lot rules across Winnipeg</h3>
        <p>10-year net additions at the same take-up rate and servicing setting.</p>
        <div className="chart-container" role="img" aria-label={scenarioRows.map(row => row.name + ' ' + format(row.homes)).join(', ')}>
          <ResponsiveContainer width="100%" height="100%" initialDimension={{width:440,height:226}}>
            <BarChart data={scenarioRows} layout="vertical" margin={{ top: 12, right: 13, bottom: 0, left: 0 }}>
              <CartesianGrid horizontal={false} stroke="#dfe8e5" />
              <XAxis type="number" tickFormatter={number.format} tickLine={false} tick={{ fontSize: 11, fill: '#526673' }} />
              <YAxis type="category" dataKey="name" width={113} tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#294351' }} />
              <Tooltip formatter={format} />
              <Bar dataKey="homes" name="Net homes" radius={[0,5,5,0]} barSize={19} isAnimationActive={false}>
                {scenarioRows.map((row,i) => <Cell key={row.name} fill={i===3 ? '#105f58' : '#86b7ad'} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </article>
      <article className="pane chart-card">
        <h3>What was permitted</h3>
        <p>{selected?.name ?? 'Winnipeg'} recorded {number.format(historicalNet)} net permitted units in 2019–2025. That pace is {number.format(annualised)} over 10 years if held constant.</p>
        <div className="chart-container" role="img" aria-label={permits.map(row => row.year + ' ' + format(row.net)).join(', ')}>
          <ResponsiveContainer width="100%" height="100%" initialDimension={{width:440,height:226}}>
            <BarChart data={permits} margin={{ top: 12, right: 10, bottom: 0, left: 0 }}>
              <CartesianGrid vertical={false} stroke="#dfe8e5" />
              <XAxis dataKey="year" tickLine={false} tick={{ fontSize: 11, fill: '#526673' }} />
              <YAxis width={49} tickFormatter={number.format} tickLine={false} tick={{ fontSize: 11, fill: '#526673' }} />
              <Tooltip formatter={format} />
              <ReferenceLine y={0} stroke="#526673" />
              <Bar dataKey="net" name="Net permitted units" fill="#496e82" radius={[4,4,0,0]} maxBarSize={35} isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </article>
      <article className="pane chart-card scatter-card">
        <div>
          <h3>Do opportunities line up with housing pressure?</h3>
          <p>Up to 15 neighbourhoods with the most simulated homes and a published 2021 rent-burden rate. The dashed line shows the Winnipeg rate of 36.0%.</p>
          {hasPositive ? <div className="chart-container scatter" role="img" aria-label="Scatter plot of rent burden and simulated net homes. Values are listed alongside.">
            <ResponsiveContainer width="100%" height="100%" initialDimension={{width:450,height:248}}>
              <ScatterChart margin={{ top: 12, right: 15, bottom: 8, left: 0 }}>
                <CartesianGrid stroke="#dfe8e5" />
                <XAxis dataKey="burden" name="Rent burden" unit="%" domain={[0,100]} type="number" tickLine={false} tick={{fontSize:11,fill:'#526673'}} />
                <YAxis dataKey="net" name="Simulated net homes" type="number" width={53} tickLine={false} tickFormatter={number.format} tick={{fontSize:11,fill:'#526673'}} />
                <Tooltip formatter={format} labelFormatter={(_, payload) => payload[0]?.payload?.name ?? ''} />
                <ReferenceLine x={36} stroke="#a64667" strokeDasharray="4 4" />
                <Scatter data={top} fill="#087867" isAnimationActive={false} />
              </ScatterChart>
            </ResponsiveContainer>
          </div> : <p className="empty-chart">Choose a scenario that adds homes to compare where they could be built.</p>}
        </div>
        {hasPositive && <div className="ranking">
          <div className="rank-head"><span>Neighbourhood</span><span>Rent burden</span><span>Net homes</span></div>
          {top.map(n => <button key={n.id} onClick={() => goToArea(n.id)}><span>{n.name}</span><span>{n.burden.toFixed(1)}%</span><strong>{number.format(n.net)}</strong></button>)}
        </div>}
      </article>
      <article className="pane chart-card">
        <h3>R1 zoning and rent burden</h3>
        <p>{zoning.length} neighbourhoods with both measures. Circle size represents 2021 population. The dashed line marks the citywide rent-burden rate.</p>
        <div className="chart-container scatter" role="img" aria-label="Scatter plot of R1 assessment share and renter housing cost burden">
          <ResponsiveContainer width="100%" height="100%" initialDimension={{width:440,height:245}}>
            <ScatterChart margin={{ top: 12, right: 16, bottom: 18, left: 0 }}>
              <CartesianGrid stroke="#dfe8e5"/>
              <XAxis dataKey="r1" name="R1 assessed share" unit="%" type="number" domain={[0,100]} tickLine={false} tick={{fontSize:11}} label={{value:'R1 share of assessed homes',position:'insideBottom',offset:-13,fontSize:11}} />
              <YAxis dataKey="burden" name="Rent burden" unit="%" type="number" domain={[0,100]} width={52} tickLine={false} tick={{fontSize:11}} />
              <ZAxis dataKey="population" name="2021 population" range={[18,154]} />
              <Tooltip formatter={format} labelFormatter={(_, payload) => payload[0]?.payload?.name ?? ''} />
              <ReferenceLine y={36} stroke="#a64667" strokeDasharray="4 4"/>
              <Scatter data={zoning} fill="#177564" fillOpacity={.66} isAnimationActive={false} onClick={(entry) => { if (entry.payload?.id) goToArea(entry.payload.id); }} />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </article>
      <article className="pane chart-card">
        <h3>Where the most homes could be added</h3>
        <p>The top 15 neighbourhoods by simulated net additions over 10 years.</p>
        {ranked.length ? <div className="ranked-bars" aria-label="Highest simulated additions">
          {ranked.map(n=><button onClick={() => goToArea(n.id)} key={n.id}><span>{n.name}</span><i aria-hidden="true"><b style={{ width: (100*n.homes/ranked[0].homes)+'%' }}/></i><strong>{number.format(n.homes)}</strong></button>)}
        </div> : <p className="empty-chart">This scenario adds no net homes.</p>}
      </article>
    </div>
  </section>;
}
