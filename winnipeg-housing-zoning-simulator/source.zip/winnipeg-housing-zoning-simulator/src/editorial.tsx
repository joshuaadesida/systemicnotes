import { ArrowUpRight, Database, Layers3, Network, Route } from 'lucide-react';
import type { Snapshot } from './types';

export const sources = {
  haf: 'https://www.winnipeg.ca/building-development/housing/housing-accelerator-fund/infill-housing',
  rewrite: 'https://engage.winnipeg.ca/zoning-rewrite',
  propertyMap: 'https://legacy.winnipeg.ca/ppd/Mapping/PropertyMap/',
  neighbourhoods: 'https://data.winnipeg.ca/d/8k6x-xxsy',
  zoning: 'https://data.winnipeg.ca/d/dxrp-w6re',
  assessment: 'https://data.winnipeg.ca/d/d4mq-wa44',
  permits: 'https://data.winnipeg.ca/d/it4w-cpf4',
  transit: 'https://gtfs.winnipegtransit.com/google_transit.zip',
  transitGuide: 'https://www.winnipeg.ca/services-programs/transportation-roads-parking/transit/understanding-network',
  census: 'https://legacy.winnipeg.ca/census/2021/',
  cityProfile: 'https://legacy.winnipeg.ca/Census/2021/City%20of%20Winnipeg/City%20of%20Winnipeg/City%20of%20Winnipeg.pdf',
  homelessness: 'https://archive.endhomelessnesswinnipeg.ca/2024-winnipeg-street-census-report/',
  homeland: 'https://www.winnipeg.ca/people-culture/winnipegs-history',
};

export function SourceLink({ href, children }: { href: string; children: React.ReactNode }) {
  return <a className="source-link" href={href} target="_blank" rel="noreferrer">{children}<ArrowUpRight size={14} aria-hidden="true" /></a>;
}

export function AuthorNote() {
  return <section className="author-section" id="author" aria-labelledby="author-title">
    <div className="shell author-grid">
      <div>
        <div className="eyebrow">A note from Joshua Adesida</div>
        <h2 id="author-title">Who gets to live in the city we build?</h2>
        <p>In the summer of 2026, I met James Veitch, the City of Winnipeg’s Manager of Urban Planning and Design, at the Outlet while the City was gathering feedback on its zoning rewrite. We got talking about the details of city planning and how resources get allocated. He invited me to his office and walked me through some of the practical issues the City was facing. I left thinking about his optimism and the choices behind each line on a zoning map.</p>
        <p>I believe Winnipeg needs zoning reform. Letting more homes be built in more neighbourhoods matters, especially near good transit. I also believe governments can build and provide housing directly. I want free housing for people who need it, low-cost homes people can keep, and permanently affordable public, non-profit and co-operative housing across the city. I built this tool to ask how much room we could make and what it would take for the people who need that room to actually live there.</p>
        <p className="credit-note">The policy positions and model assumptions here are my own.</p>
        <SourceLink href={sources.rewrite}>City of Winnipeg zoning rewrite</SourceLink>
      </div>
      <aside className="equity-card">
        <div className="eyebrow">Land, power and housing</div>
        <p className="equity-stat">79.9<span>%</span></p>
        <p className="stat-description">of respondents in Winnipeg’s 2024 Street Census identified as Indigenous.</p>
        <p>The count identified 2,469 people experiencing homelessness on one night. It necessarily missed people. Winnipeg is on Treaty 1 territory and in the homeland of the Red River Métis. The disproportionate homelessness of Indigenous people on land taken from Indigenous peoples is a moral failure. For me, that means putting public land and money behind Indigenous-led housing and respecting Indigenous authority over how it is planned and delivered.</p>
        <div className="source-row"><SourceLink href={sources.homelessness}>2024 Street Census</SourceLink><SourceLink href={sources.homeland}>Winnipeg’s history</SourceLink></div>
      </aside>
    </div>
  </section>;
}

export function Methods({ data }: { data: Snapshot | null }) {
  const m = data?.metadata;
  const available = data?.features.filter((f) => f.properties.census?.rentBurden != null).length;
  const mapped = data?.features.reduce((a, f) => a + f.properties.mappedCandidates, 0);
  const candidates = data?.features.reduce((a, f) => a + f.properties.candidates, 0);
  return <section className="methods-section shell" id="methods" aria-labelledby="methods-title">
    <div className="eyebrow">Sources &amp; methods</div>
    <h2 id="methods-title">Where the numbers come from</h2>
    <p className="section-lede">The snapshot combines municipal records from different years. Open each note to see how the values were constructed and where the model stops.</p>
    <div className="details-list">
      <details><summary><Layers3 size={19} />Zoning and the candidate pool</summary><div className="detail-content">
        <p>Every mapped detached dwelling assessment record in R1S, R1M, R1L, R1E, R2 or RMFS is a candidate. The model treats each record as one existing dwelling. The R1 map layer counts residential assessment records with those four R1 designations and divides by residential records with any recorded zoning. Vacant land is excluded from that denominator. Assessment records can represent condo units or whole buildings, so this is a share of assessment records. The denominator counts records rather than hectares.</p>
        <p>The map uses the City’s neighbourhood boundaries, joining assessment and permit data by normalized name with documented aliases. {m ? <>{data?.features.length} polygons are shown. {m.assessmentUnmatched} detached assessment records and {m.permitNetUnmatched} net permitted units with unmatched neighbourhoods are excluded from the mapped totals.</> : null}</p>
        <p>The June 2025 Housing Accelerator Fund amendments allow up to four units on many residential sites subject to conditions. They also allow taller four-unit buildings on certain properties within the City’s mapped frequent transit areas. The simulator abstracts from those conditions. Check the City’s official property map and applicable bylaws for a specific address. The broader zoning rewrite is a separate process.</p>
        <div className="source-row"><SourceLink href={sources.assessment}>Assessment parcels</SourceLink><SourceLink href={sources.neighbourhoods}>Neighbourhood boundaries</SourceLink><SourceLink href={sources.zoning}>Zoning districts</SourceLink><SourceLink href={sources.haf}>HAF infill amendments</SourceLink><SourceLink href={sources.propertyMap}>Official property map</SourceLink></div>
      </div></details>
      <details><summary><Route size={19} />Frequent transit and servicing</summary><div className="detail-content">
        <p>The blue overlay is the union of 800 m straight-line buffers around Winnipeg Transit’s scheduled BLUE, F and FX route stops. These are the Rapid, Frequent and Frequent Express service categories. A candidate is marked near transit if a point inside its parcel falls within the buffer. {m && mapped && candidates ? <>{mapped.toLocaleString('en-CA')} of {candidates.toLocaleString('en-CA')} matched candidates had usable geometry. The GTFS feed covers {m.transitPeriod}.</> : null} Street crossings, actual walks, and the City’s official eligibility map can produce different results.</p>
        <p>The servicing switch reduces the annual take-up rate by 40% everywhere as a sensitivity test. It represents a hypothetical slowdown. A sewer and water capacity review would be needed to make claims about specific neighbourhoods.</p>
        <div className="source-row"><SourceLink href={sources.transitGuide}>Transit service types</SourceLink><SourceLink href={sources.transit}>Winnipeg Transit GTFS ZIP</SourceLink></div>
      </div></details>
      <details><summary><Network size={19} />Compounding, the tax assumption and public delivery</summary><div className="detail-content">
        <p>Each year the selected share of the remaining candidates redevelops. After 10 years, the share redeveloped is 1 − (1 − annual take-up)¹⁰. The HAF-inspired preset uses a four-home cap and includes all near-transit candidates and a representative 25% of the remainder. That 25% is a modelling assumption. Turn off the pool limit to include all candidates. Regular candidates add the lot cap minus one dwelling. With the transit option on, near-transit candidates add 12 net homes instead. The two groups use the same candidate pool. The calculation omits site assembly, project viability, demolitions beyond the assumed existing dwelling, and development on most commercial, vacant and public sites.</p>
        <p>The tax scenario multiplies net additions by an assumed $2,450 CAD per added unit per year. This is the year-10 gross annual amount under that assumption. Actual assessment, mill rates, exemptions and service costs are outside this model. The public and non-market slider allocates a share of the same simulated net homes. It assumes that commitment is funded and delivered. The tool does not estimate rents or homelessness outcomes.</p>
      </div></details>
      <details><summary><Database size={19} />Building permits and census measures</summary><div className="detail-content">
        <p>The detailed permit records include applications that were issued or closed. Housing-changing records dated 2019–2025 are summed by issue year, using reported dwelling units created minus lost. The source lists two different names for permit neighbourhood code 5.530. Those records follow their published neighbourhood names. The series measures permits rather than starts, completions or the isolated impact of zoning reform. How multi-unit permits were recorded changed in November 2022. A zero means no net units were recorded in the selected scope.</p>
        <p>Rent burden is the published share of eligible renter households spending at least 30% of income on shelter. Its denominator is tenant households in non-farm, non-reserve private dwellings in the City profile. Citywide it was 36.0% in 2021. {available != null ? <>{available} mapped neighbourhoods had readable published rent-burden values. </> : null} Missing or suppressed neighbourhood values stay unavailable. Neighbourhood counts refer to the census profile’s non-institutional population. Median household income is reported for the census income reference year, 2020.</p>
        <div className="source-row"><SourceLink href={sources.permits}>Detailed building permits</SourceLink><SourceLink href={sources.census}>2021 neighbourhood profiles</SourceLink><SourceLink href={sources.cityProfile}>2021 Winnipeg city profile</SourceLink></div>
      </div></details>
    </div>
    {m && <p className="snapshot">Source snapshot retrieved {m.retrieved}.</p>}
    <div className="source-row"><SourceLink href="./source.zip">Download the source code and data</SourceLink></div>
  </section>;
}
