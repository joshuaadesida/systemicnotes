import type { Neighbourhood } from './types';

export interface Scenario {
  cap: number;
  takeUp: number;
  corridor: boolean;
  limitedPool: boolean;
  servicing: boolean;
  nonMarket: number;
}

export const plans = {
  reference: { label: 'One-unit reference', scenario: { cap: 1, takeUp: 1.0, corridor: false, limitedPool: false, servicing: false, nonMarket: 0 } },
  haf: { label: 'Four units · HAF-inspired', scenario: { cap: 4, takeUp: 1.0, corridor: false, limitedPool: true, servicing: false, nonMarket: 0 } },
  missingMiddle: { label: 'Six units + transit', scenario: { cap: 6, takeUp: 1.0, corridor: true, limitedPool: false, servicing: false, nonMarket: 20 } },
} satisfies Record<string, { label: string; scenario: Scenario }>;

export const YEARS = 10;
export const TAX_PER_UNIT = 2450;
export const CORRIDOR_NET_UNITS = 12;
export const SERVICING_FACTOR = 0.6;

export function project(neighbourhood: Neighbourhood, scenario: Scenario) {
  const annualRate = scenario.takeUp / 100 * (scenario.servicing ? SERVICING_FACTOR : 1);
  const decadeShare = 1 - (1 - annualRate) ** YEARS;
  // Apply the lot cap to each cohort once, with a separate yield for the optional transit bonus.
  const near = neighbourhood.near;
  const outside = (neighbourhood.candidates - near) * (scenario.limitedPool ? .25 : 1);
  const baseNet = scenario.cap - 1;
  const net = decadeShare * (outside * baseNet + near * (scenario.corridor ? CORRIDOR_NET_UNITS : baseNet));
  return { net, nonMarket: net * scenario.nonMarket / 100, tax: net * TAX_PER_UNIT };
}

export const number = new Intl.NumberFormat('en-CA', { maximumFractionDigits: 0 });
export const money = new Intl.NumberFormat('en-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 0 });

export type Metric = 'yield' | 'r1' | 'burden' | 'transit' | 'permits';
export const metrics: Record<Metric, {
  label: string; edges: [number, number, number]; bins: [string, string, string, string];
  colours: [string, string, string, string]; value: (n: Neighbourhood, s: Scenario) => number | null;
}> = {
  yield: { label: 'Simulated net units', edges: [1, 50, 250], bins: ['0', '1–49', '50–249', '250+'],
    colours: ['#e6eeeb','#a4cfc3','#4b9c8a','#136557'], value: (n,s) => Math.round(project(n,s).net) },
  r1: { label: 'R1 share of assessed homes', edges: [25,45,75], bins: ['Under 25%', '25–44%', '45–74%', '75%+'],
    colours: ['#c2dfd5','#68ab9e','#e9b76f','#c77375'], value: (n) => ratio(n.r1,n.residential) },
  burden: { label: 'Rent burden · 2021', edges: [25,36,50], bins: ['Under 25%', '25–35%', '36–49%', '50%+'],
    colours: ['#ede5e6','#e0b1bb','#c87991','#a64667'], value: (n) => n.census?.rentBurden ?? null },
  transit: { label: 'Detached homes near transit', edges: [1, 35, 70], bins: ['Under 1%', '1–34%', '35–69%', '70%+'],
    colours: ['#e5edf5','#aac5df','#649ac9','#2e6598'], value: (n) => ratio(n.near,n.mappedCandidates) },
  permits: { label: 'Net permitted units · 2019–25', edges: [1,50,250], bins: ['0 or fewer','1–49','50–249','250+'],
    colours: ['#e8eeeb','#c3cdb4','#8fa274','#577342'], value: (n) => n.created-n.lost },
};

export function ratio(numerator: number, denominator: number) {
  return denominator > 0 ? 100 * numerator / denominator : null;
}
export function percentage(value: number | null) {
  return value == null ? 'Unavailable' : value.toFixed(1) + '%';
}
export const missingColour = '#d9dde0';

export function metricColour(metric: Metric, n: Neighbourhood, scenario: Scenario) {
  const spec = metrics[metric];
  const value = spec.value(n, scenario);
  if (value == null) return missingColour;
  return spec.colours[spec.edges.filter((edge) => value >= edge).length];
}
