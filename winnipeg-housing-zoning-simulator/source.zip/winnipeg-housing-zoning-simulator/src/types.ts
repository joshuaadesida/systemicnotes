import type { Feature, FeatureCollection, MultiPolygon, Polygon } from 'geojson';

export interface Neighbourhood {
  id: string;
  name: string;
  areaHa: number;
  r1: number;
  residential: number;
  candidates: number;
  mappedCandidates: number;
  near: number;
  created: number;
  lost: number;
  permits: number;
  history: number[];
  census: {
    population: number | null;
    income: number | null;
    tenantShare: number | null;
    rentBurden: number | null;
    source: string;
  } | null;
}
export type NeighbourhoodFeature = Feature<Polygon | MultiPolygon, Neighbourhood>;
export interface Snapshot extends FeatureCollection<Polygon | MultiPolygon, Neighbourhood> {
  metadata: {
    retrieved: string;
    transitPeriod: string;
    transitRoutes: number;
    permitsStart: number;
    permitsEnd: number;
    censusProfiles: number;
    assessmentUnmatched: number;
    permitNetUnmatched: number;
  };
  transit: FeatureCollection<Polygon | MultiPolygon>;
}
