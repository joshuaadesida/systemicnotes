import { useEffect, useRef, useState } from 'react';
import maplibre, { Map as LibreMap, type GeoJSONSource } from 'maplibre-gl';
import type { FeatureCollection, MultiPolygon, Polygon, Position } from 'geojson';
import { metricColour, type Metric, type Scenario } from './model';
import type { Neighbourhood, Snapshot } from './types';
import 'maplibre-gl/dist/maplibre-gl.css';

type MapProps = {
  data: Snapshot; selected: string; metric: Metric; scenario: Scenario;
  showTransit: boolean; onSelect: (id: string) => void;
};
const CITY_BOUNDS: [[number, number], [number, number]] = [[-97.345,49.706],[-96.930,50.019]];

function svgPath(geometry: Polygon | MultiPolygon) {
  const west = CITY_BOUNDS[0][0], south = CITY_BOUNDS[0][1], east = CITY_BOUNDS[1][0], north = CITY_BOUNDS[1][1];
  const polygons = geometry.type === 'Polygon' ? [geometry.coordinates] : geometry.coordinates;
  return polygons.map((polygon) => polygon.map((ring) =>
    ring.map(([x,y], idx) => (idx ? 'L' : 'M') + ((x-west)/(east-west)*534+10).toFixed(1) + ' ' +
      ((north-y)/(north-south)*600+10).toFixed(1)).join('') + 'Z').join('')).join('');
}

function VectorFallback({ data, selected, metric, scenario, showTransit, onSelect }: MapProps) {
  return <svg className="svg-map" viewBox="0 0 554 620" role="group" aria-label="Selectable Winnipeg neighbourhood map">
    {data.features.map(({ geometry, properties: n }) =>
      <path key={n.id} d={svgPath(geometry)} fill={metricColour(metric,n,scenario)} stroke="#f3f7f5" strokeWidth=".9"
        fillRule="evenodd" className="map-shape" onClick={() => onSelect(n.id)}><title>{n.name}</title></path>)}
    {showTransit && data.transit.features.map(({ geometry }, i) =>
      <path key={i} d={svgPath(geometry)} fill="#3778bd" fillRule="evenodd" opacity=".23" stroke="#1e5792" strokeWidth="1.5" pointerEvents="none" />)}
    {data.features.filter((f) => f.properties.id === selected).map(({ geometry, properties: n }) =>
      <path key={n.id} d={svgPath(geometry)} fill="none" fillRule="evenodd" stroke="#133b45" strokeWidth="2.5" pointerEvents="none" />)}
  </svg>;
}

export default function MapWorkspace(props: MapProps) {
  const { data, selected, showTransit, metric, scenario, onSelect } = props;
  const host = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LibreMap | null>(null);
  const choose = useRef(onSelect);
  const [status, setStatus] = useState<'loading' | 'ready' | 'fallback'>('loading');

  useEffect(() => { choose.current = onSelect; }, [onSelect]);

  useEffect(() => {
    if (!host.current) return;
    let map: LibreMap;
    try {
      map = new maplibre.Map({
        container: host.current, bounds: CITY_BOUNDS, fitBoundsOptions: { padding: 18 },
        attributionControl: false, maxZoom: 15, minZoom: 8, dragRotate: false, pitchWithRotate: false,
        style: {
          version: 8, sources: {
            neighbourhoods: { type: 'geojson', data },
            transit: { type: 'geojson', data: data.transit },
          }, layers: [
            { id: 'base', type: 'background', paint: { 'background-color': '#e3ebee' } },
            { id: 'housing', source: 'neighbourhoods', type: 'fill', paint: { 'fill-color': '#d9e7e3', 'fill-opacity': .98 } },
            { id: 'roads', source: 'neighbourhoods', type: 'line', paint: { 'line-color': '#f6faf8', 'line-width': 1.1 } },
            { id: 'transit-fill', source: 'transit', type: 'fill', layout: { visibility: 'none' },
              paint: { 'fill-color': '#4884bc', 'fill-opacity': .19 } },
            { id: 'transit-border', source: 'transit', type: 'line', layout: { visibility: 'none' },
              paint: { 'line-color': '#23649f', 'line-width': 1.2, 'line-dasharray': [3,2] } },
            { id: 'selection', source: 'neighbourhoods', type: 'line', filter: ['==',['get','id'],''],
              paint: { 'line-color': '#17394b', 'line-width': 3 } },
          ],
        },
      });
    } catch {
      setStatus('fallback');
      return;
    }
    mapRef.current = map;
    map.scrollZoom.disable();
    map.addControl(new maplibre.NavigationControl({ showCompass: false }), 'top-right');
    const popup = new maplibre.Popup({ closeButton: false, closeOnClick: false, offset: 13, className: 'neighbourhood-popup' });
    map.on('load', () => setStatus('ready'));
    map.on('error', () => { if (!map.isStyleLoaded()) setStatus('fallback'); });
    map.on('click', 'housing', ({ features }) => { if (features?.[0]) choose.current(String(features[0].properties.id)); });
    map.on('mousemove', 'housing', ({ features, lngLat }) => {
      const name = features?.[0]?.properties.name;
      if (!name) return;
      map.getCanvas().style.cursor = 'pointer';
      if (!map.isMoving()) popup.setLngLat(lngLat).setText(String(name)).addTo(map);
    });
    map.on('mouseleave', 'housing', () => { map.getCanvas().style.cursor = ''; popup.remove(); });
    return () => { popup.remove(); map.remove(); mapRef.current = null; };
  }, [data]);

  useEffect(() => {
    if (status !== 'ready' || !mapRef.current) return;
    const map = mapRef.current;
    const coloured: FeatureCollection<Polygon | MultiPolygon, Neighbourhood & { colour: string }> = {
      type: 'FeatureCollection', features: data.features.map((f) => ({
        ...f, properties: { ...f.properties, colour: metricColour(metric,f.properties,scenario) },
      })),
    };
    (map.getSource('neighbourhoods') as GeoJSONSource).setData(coloured);
    map.setPaintProperty('housing', 'fill-color', ['coalesce', ['get','colour'], '#d9e7e3']);
  }, [status, data, metric, scenario]);

  useEffect(() => {
    if (status !== 'ready' || !mapRef.current) return;
    const map = mapRef.current;
    map.setFilter('selection',['==',['get','id'],selected]);
    const choice = data.features.find((p) => p.properties.id === selected);
    if (!choice) { map.fitBounds(CITY_BOUNDS, { padding: 18, duration: 0 }); return; }
    const ring = choice.geometry.type === 'Polygon'
      ? choice.geometry.coordinates.flat() : choice.geometry.coordinates.flat(2);
    const bbox = ring.reduce<[number,number,number,number]>((acc,[x,y]: Position) =>
      [Math.min(acc[0],x),Math.min(acc[1],y),Math.max(acc[2],x),Math.max(acc[3],y)],
      [180,90,-180,-90]);
    const box = map.getBounds();
    if (!box.contains([bbox[0],bbox[1]]) || !box.contains([bbox[2],bbox[3]])) {
      map.fitBounds([[bbox[0],bbox[1]],[bbox[2],bbox[3]]], { padding: 40, maxZoom: 12.4, duration: 180 });
    }
  }, [data, selected, status]);

  useEffect(() => {
    if (status !== 'ready' || !mapRef.current) return;
    for (const id of ['transit-fill','transit-border']) {
      mapRef.current.setLayoutProperty(id,'visibility',showTransit ? 'visible' : 'none');
    }
  }, [showTransit,status]);

  return <div className="map-stage">
    <div ref={host} className="maplibre-host" aria-label="Interactive map of Winnipeg neighbourhoods" hidden={status === 'fallback'} />
    {status === 'fallback' && <VectorFallback {...props} />}
    {status === 'loading' && <span className="map-loading" role="status">Loading the map…</span>}
    <span className="map-credit">City of Winnipeg · Winnipeg Transit</span>
  </div>;
}
