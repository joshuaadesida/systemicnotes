import { lazy, Suspense, useEffect, useMemo, useState, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowDown, ArrowLeft, ArrowRight, BookOpen, Building2, ChevronDown, Home, MapPin, RotateCcw, TrainFront, Trees, Waypoints } from 'lucide-react';
import { AuthorNote, Methods, SourceLink, sources } from './editorial';
import { metrics, missingColour, money, number, percentage, plans, project, ratio, type Metric, type Scenario } from './model';
import type { Neighbourhood, Snapshot } from './types';
import './styles.css';

const MapWorkspace = lazy(() => import('./MapWorkspace'));
const Evidence = lazy(() => import('./Evidence'));

const defaultScenario: Scenario = plans.haf.scenario;
const layerKeys = Object.keys(metrics) as Metric[];
const presets = Object.entries(plans);
const selectedUrl = new URLSearchParams(window.location.search);
const initialMetric = layerKeys.find(key => key === selectedUrl.get('layer')) ?? 'yield';
const initialNeighbourhood = selectedUrl.get('area') ?? '';
const initialBounds: Record<'cap' | 'takeUp' | 'nonMarket',[number,number]> = { cap:[1,6], takeUp:[.4,2.5], nonMarket:[0,100] };

function initialScenario() {
  const value = { ...defaultScenario };
  (Object.keys(initialBounds) as (keyof typeof initialBounds)[]).forEach(key => {
    const raw = selectedUrl.get(key);
    if (raw == null || raw.trim() === '') return;
    const parsed = Number(raw);
    const [min,max] = initialBounds[key];
    if (Number.isFinite(parsed) && parsed >= min && parsed <= max) value[key] = key === 'takeUp' ? Math.round(parsed*10)/10 : Math.round(parsed);
  });
  value.corridor = selectedUrl.get('corridor') === '1';
  value.limitedPool = selectedUrl.has('limitedPool') ? selectedUrl.get('limitedPool') === '1' : defaultScenario.limitedPool;
  value.servicing = selectedUrl.get('servicing') === '1';
  return value;
}

const closeEnough = (a: Scenario,b: Scenario) =>
  a.cap===b.cap && a.takeUp===b.takeUp && a.corridor===b.corridor && a.limitedPool===b.limitedPool && a.servicing===b.servicing && a.nonMarket===b.nonMarket;

const dataset = new URL('./winnipeg_haf_neighbourhoods.geojson', document.baseURI);

function HeroMap({ data }: { data: Snapshot | null }) {
  const drawing = useMemo(() => {
    if (!data) return [];
    return data.features.map(({geometry, properties: area}) => {
      const polygons = geometry.type === 'MultiPolygon' ? geometry.coordinates : [geometry.coordinates];
      const path = polygons.map(p => p.map(ring => ring.map(([x,y],i) =>
        (i?'L':'M') + ((x+97.37)*1200).toFixed(1) + ',' + ((50.035-y)*1600).toFixed(1)).join('') + 'Z').join('')).join('');
      const share = ratio(area.near,area.mappedCandidates) ?? 0;
      return { id:area.id, path, fill:share>=70?'#4c9c84':share>=33?'#2c665f':share>0?'#244f50':'#1d4047' };
    });
  }, [data]);
  return <div className="hero-map" aria-hidden="true">
    <svg viewBox="0 0 550 545" focusable="false">
      <g transform="translate(0 9)">
        {drawing.map(shape => <path d={shape.path} key={shape.id} fill={shape.fill} fillRule="evenodd" stroke="#83b4a7" strokeOpacity=".52" strokeWidth="1" />)}
      </g>
    </svg>
    <div className="hero-map-label"><span></span>Detached homes near frequent transit<br/><small>Winnipeg, Manitoba</small></div>
  </div>;
}

function Slider({ label, value, min, max, step, output, note, change }: {
  label: string; value: number; min: number; max: number; step: number; output: string; note: string;
  change: (value: number) => void;
}) {
  return <label className="slider">
    <span className="slider-label">{label}<strong>{output}</strong></span>
    <input type="range" min={min} max={max} step={step} value={value} aria-valuetext={output} onChange={e => change(Number(e.currentTarget.value))} />
    <span className="control-note">{note}</span>
  </label>;
}

function Toggle({ title, note, active, change, icon }: {
  title: string; note: string; active: boolean; change: (value: boolean) => void; icon: ReactNode;
}) {
  return <label className="toggle">
    <span className="toggle-icon">{icon}</span>
    <span className="toggle-copy"><strong>{title}</strong><span>{note}</span></span>
    <input type="checkbox" checked={active} onChange={e => change(e.currentTarget.checked)} />
    <span className="switch" aria-hidden="true" />
  </label>;
}

function brief(n: Neighbourhood | undefined, scenario: Scenario, net: number) {
  if (n?.candidates === 0) return 'This neighbourhood has no detached candidates in the model. Other development opportunities could still exist.';
  if (net === 0) return 'At these settings, the model adds no net homes. Try a higher lot cap or enable the transit bonus.';
  if (scenario.nonMarket === 0) return 'Your scenario has no public or non-market delivery commitment. Add one to see how many of these homes it would reserve.';
  return 'This allocation would take public financing, land, and an organization that can build and keep the homes affordable.';
}

function App() {
  const [data, setData] = useState<Snapshot | null>(null);
  const [problem, setProblem] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [scenario, setScenario] = useState(initialScenario);
  const [metric, setMetric] = useState<Metric>(initialMetric);
  const [area, setArea] = useState(initialNeighbourhood);
  const [overlay, setOverlay] = useState(selectedUrl.get('overlay') === '1');
  const [copied, setCopied] = useState('');
  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    setProblem(false);
    fetch(dataset,{signal:controller.signal}).then(async response => {
      if (!response.ok) throw new Error('Snapshot unavailable');
      const snapshot: Snapshot = await response.json();
      if (snapshot.type !== 'FeatureCollection' || !snapshot.features.length) throw new Error('Invalid snapshot');
      setData(snapshot);
    }).catch(() => { if (!controller.signal.aborted) setProblem(true); });
    return () => controller.abort();
  }, [attempt]);
  const sorted = useMemo(() => data?.features.map(p=>p.properties).sort((a,b)=>a.name.localeCompare(b.name,'en-CA')) ?? [],[data]);
  const selected = sorted.find(n=>n.id===area);
  const summary = useMemo(() => (selected ? [selected] : sorted).reduce((out,n) => {
    const result = project(n,scenario);
    return { net: out.net+result.net, tax:out.tax+result.tax, nonMarket:out.nonMarket+result.nonMarket,
      candidates:out.candidates+n.candidates, mapped:out.mapped+n.mappedCandidates, near:out.near+n.near };
  },{ net:0,tax:0,nonMarket:0,candidates:0,mapped:0,near:0 }), [scenario, selected, sorted]);

  function change<K extends keyof Scenario>(key: K,value: Scenario[K]) { setScenario(s => ({...s,[key]:value})); }
  function choose(id:string) { setArea(id); setQuery(''); setSearchOpen(false); }
  const matches = query.trim() ? sorted.filter(n=>n.name.toLowerCase().includes(query.toLowerCase().trim())).slice(0,8) : [];

  async function share() {
    const url = new URL(window.location.href);
    url.search = '';
    url.hash = 'simulator';
    for (const [key, value] of Object.entries(scenario)) url.searchParams.set(key, typeof value === 'boolean' ? (value?'1':'0') : String(value));
    if (selected) url.searchParams.set('area', selected.id);
    if (metric!=='yield') url.searchParams.set('layer',metric);
    if (overlay) url.searchParams.set('overlay','1');
    try {
      await navigator.clipboard.writeText(url.href);
      setCopied('Link copied');
    } catch {
      setCopied(url.href);
    }
  }

  function download() {
    const header = ['Neighbourhood','Candidate records','Transit candidates with usable geometry','Candidates near transit','Simulated net homes','Gross annual property tax CAD','Public and non-market allocation','2021 tenant rent burden percent','2019–2025 net permitted units','Units per lot','Annual take-up percent','Transit bonus enabled','Outside transit pool limited','Servicing stress test','Non-market target percent'];
    const rows = sorted.map(n => {
      const simulated = project(n,scenario);
      return [n.name,n.candidates,n.mappedCandidates,n.near,simulated.net.toFixed(2),simulated.tax.toFixed(2),simulated.nonMarket.toFixed(2),n.census?.rentBurden??'',n.created-n.lost,scenario.cap,scenario.takeUp,scenario.corridor,scenario.limitedPool,scenario.servicing,scenario.nonMarket];
    });
    const csv = [header,...rows].map(row => row.map(cell => '"' + String(cell).replaceAll('"','""') + '"').join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob(['\uFEFF',csv],{type:'text/csv;charset=utf-8'}));
    const link = document.createElement('a');
    link.href=url;
    link.download='systemicnotes-winnipeg-housing-scenario.csv';
    link.click();
    window.setTimeout(()=>URL.revokeObjectURL(url),1000);
  }

  const title = selected?.name ?? 'All Winnipeg';
  const readout = brief(selected, scenario, summary.net);

  return <>
    <a className="skip" href="#simulator">Skip to the simulator</a>
    <header className="masthead">
      <div className="shell masthead-inner">
        <a href="../" className="brand"><span className="brand-icon"><Waypoints size={18}/></span>SystemicNotes</a>
        <span className="byline">Joshua Adesida</span>
        <nav aria-label="On this page"><a href="#simulator">Simulator</a><a href="#evidence">Evidence</a><a href="#author">Author’s note</a><a href="#methods">Methods</a></nav>
      </div>
    </header>
    <main>
      <section className="hero">
        <div className="shell hero-inner">
          <div className="hero-copy">
            <div className="hero-kicker"><MapPin size={15}/> WINNIPEG, MANITOBA</div>
            <h1>Winnipeg Housing <em>&amp; Zoning Reform</em> Simulator</h1>
            <p>I built this to ask where Winnipeg could make room for more homes, and what it would take to make those homes affordable.</p>
            <div className="hero-actions">
              <a className="button primary" href="#simulator">Explore the simulator <ArrowDown size={17}/></a>
              <a className="hero-link" href="#author">Why I built this <ArrowRight size={16}/></a>
            </div>
          </div>
          <HeroMap data={data} />
        </div>
      </section>
      <section id="simulator" className="shell simulation" aria-labelledby="sim-title">
        <div className="section-heading">
          <div><div className="eyebrow">Interactive simulator</div><h2 id="sim-title">Test a zoning scenario</h2></div>
          {data && <button onClick={share} className="button secondary">Copy scenario link</button>}
        </div>
        <p className="section-lede">Change the rules below, then select a neighbourhood to see how the same assumptions play out locally. Results represent ten years of hypothetical redevelopment.</p>
        {copied && <p className="share-result" role="status">{copied.startsWith('http') ? <input value={copied} readOnly aria-label="Scenario link" onFocus={e=>e.currentTarget.select()}/> : copied}</p>}
        {problem && <div className="notice" role="alert">The data could not load. <button onClick={() => setAttempt(n=>n+1)}>Try again</button></div>}
        {!data && !problem && <div className="notice" role="status">Loading the Winnipeg data…</div>}
        {data && <>
          <div className="workspace">
            <aside className="pane controls" aria-label="Scenario controls">
              <div className="control-heading"><h3>Scenario settings</h3><button className="icon-button" aria-label="Reset scenario" title="Reset scenario" onClick={() => { setScenario(defaultScenario); setMetric('yield'); setOverlay(false); choose(''); }}><RotateCcw size={17}/></button></div>
              <div className="presets" role="group" aria-label="Scenario presets">
                {presets.map(([id,p]) => <button key={id} aria-pressed={closeEnough(scenario,p.scenario)} onClick={()=>{setScenario(p.scenario); if(p.scenario.corridor) setOverlay(true);}}>{p.label}</button>)}
              </div>
              <Slider label="Maximum homes per lot" value={scenario.cap} min={1} max={6} step={1} output={String(scenario.cap)} note="Assumes one existing home is replaced." change={value=>change('cap',value)} />
              <Slider label="Annual redevelopment" value={scenario.takeUp} min={.4} max={2.5} step={.1} output={scenario.takeUp.toFixed(1)+'%'} note="Share of remaining candidates redeveloped each year." change={value=>change('takeUp',value)} />
              <div className="switches">
                <Toggle title="Limit the pool outside transit" note="Include 25% of candidates outside the buffer or without usable geometry." icon={<MapPin size={16}/>} active={scenario.limitedPool} change={value=>change('limitedPool',value)} />
                <Toggle title="Frequent transit bonus" note="12 net homes per redeveloped candidate within 800 m." icon={<TrainFront size={16}/>} active={scenario.corridor} change={value=>{change('corridor',value); if(value) setOverlay(true);}} />
                <Toggle title="Servicing stress test" note="Reduce take-up by 40% across the model." icon={<Trees size={16}/>} active={scenario.servicing} change={value=>change('servicing',value)} />
              </div>
              <div className="non-market-slider">
                <Slider label="Public and non-market share" value={scenario.nonMarket} min={0} max={100} step={1} output={scenario.nonMarket+'%'} note="Share of simulated net homes reserved by policy." change={value=>change('nonMarket',value)} />
              </div>
            </aside>
            <div className="pane map-pane">
              <div className="map-toolbar">
                <label><span>Map layer</span><span className="select-wrap"><select aria-label="Map layer" value={metric} onChange={e=>setMetric(e.currentTarget.value as Metric)}>{layerKeys.map(k=><option key={k} value={k}>{metrics[k].label}</option>)}</select><ChevronDown size={16}/></span></label>
                <label className="overlay-toggle"><input type="checkbox" checked={overlay} onChange={e=>setOverlay(e.currentTarget.checked)}/>800 m transit overlay</label>
              </div>
              <div className="map-viewport">
                <Suspense fallback={<div className="map-loading" role="status">Loading the map…</div>}>
                  <MapWorkspace data={data} selected={selected?.id ?? ''} showTransit={overlay} metric={metric} scenario={scenario} onSelect={choose} />
                </Suspense>
              </div>
              <div className="legend" aria-label="Map legend">
                {metrics[metric].bins.map((label,i)=><span key={label}><i style={{background:metrics[metric].colours[i]}}/>{label}</span>)}
                {(metric==='r1'||metric==='burden'||metric==='transit') && <span><i style={{background:missingColour}}/>Unavailable</span>}
              </div>
            </div>
            <aside className="pane inspector" aria-label="Neighbourhood explorer">
              <h3>Neighbourhood explorer</h3>
              <label htmlFor="area-select">Find a neighbourhood</label>
              <div className="select-wrap"><select id="area-select" value={selected?.id ?? ''} onChange={e=>choose(e.currentTarget.value)}><option value="">All Winnipeg</option>{sorted.map(n=><option key={n.id} value={n.id}>{n.name}</option>)}</select><ChevronDown size={16}/></div>
              <div className="search-wrap">
                <input aria-label="Search by neighbourhood name" placeholder="Or type a name" type="search" value={query} onChange={e=>{setQuery(e.currentTarget.value); setSearchOpen(true);}} onFocus={()=>setSearchOpen(true)} onKeyDown={e=>{if(e.key==='Escape') setSearchOpen(false); if(e.key==='Enter'&&matches[0]) choose(matches[0].id);}}/>
                {searchOpen && query.trim() && <div className="search-results">{matches.length ? matches.map(n=><button key={n.id} onClick={()=>choose(n.id)}>{n.name}</button>) : <span>No matches</span>}</div>}
              </div>
              <div className="inspect-title"><MapPin size={16}/><strong>{title}</strong></div>
              <dl>
                <div><dt>Detached candidates</dt><dd>{number.format(summary.candidates)}</dd></div>
                <div><dt>Near frequent transit</dt><dd>{number.format(summary.near)} · {percentage(ratio(summary.near,summary.mapped))}</dd></div>
                <div><dt>Rent burden · 2021</dt><dd>{percentage(selected ? selected.census?.rentBurden ?? null : 36)}</dd></div>
                {selected && <>
                  <div><dt>Net permitted units · 2019–25</dt><dd>{number.format(selected.created-selected.lost)}</dd></div>
                  <div><dt>R1 assessed share</dt><dd>{percentage(ratio(selected.r1,selected.residential))}</dd></div>
                  <div><dt>Population · 2021</dt><dd>{selected.census?.population==null ? 'Unavailable':number.format(selected.census.population)}</dd></div>
                  <div><dt>Median household income · 2020</dt><dd>{selected.census?.income==null?'Unavailable':money.format(selected.census.income)}</dd></div>
                  <div><dt>Renter households · 2021</dt><dd>{percentage(selected.census?.tenantShare ?? null)}</dd></div>
                </>}
              </dl>
              {selected && selected.residential > 0 && <div className="zoning-breakdown">
                <div aria-label={percentage(ratio(selected.r1,selected.residential)) + ' R1 designated assessment records'}><span style={{width:((selected.r1/selected.residential)*100)+'%'}} /></div>
                <small>R1 <b>{number.format(selected.r1)}</b> · Other <b>{number.format(selected.residential-selected.r1)}</b></small>
              </div>}
              <SourceLink href={selected?.census?.source ?? (selected ? sources.census : sources.cityProfile)}>{selected ? 'City census profiles' : 'Winnipeg census profile'}</SourceLink>
            </aside>
          </div>
          <div className="metric-grid" aria-label={title + ' scenario results'} aria-live="polite">
            <article><Home size={21}/><span>Net homes over 10 years</span><strong>{number.format(summary.net)}</strong><small>{title} · simulated</small></article>
            <article><Building2 size={21}/><span>Gross annual property tax</span><strong>{money.format(summary.tax)}</strong><small>Year 10 · $2,450 per added home</small></article>
            <article><Waypoints size={21}/><span>Public and non-market homes</span><strong>{number.format(summary.nonMarket)}</strong><small>{scenario.nonMarket}% allocation · included in net homes</small></article>
          </div>
          <div className="interpretation"><BookOpen size={20}/><p>{readout}</p><a href="#methods">Read the assumptions <ArrowRight size={14}/></a></div>
        </>}
      </section>
      {data && <Suspense fallback={<p className="shell notice">Loading scenario charts…</p>}><Evidence data={data} scenario={scenario} selected={selected} onSelect={choose} download={download}/></Suspense>}
      <AuthorNote />
      <Methods data={data}/>
    </main>
    <footer><div className="shell footer-inner"><a className="brand" href="../"><span className="brand-icon"><Waypoints size={17}/></span>SystemicNotes</a><small>Research and writing by Joshua Adesida</small><a className="back" href="../"><ArrowLeft size={16}/>All projects</a></div></footer>
  </>;
}

createRoot(document.getElementById('root')!).render(<App />);
