import subprocess, pathlib, urllib.parse, concurrent.futures
import sys
r = pathlib.Path(sys.argv[1])
r.mkdir(parents=True, exist_ok=True)
endpoint='https://data.winnipeg.ca/resource/d4mq-wa44.json'
where="property_use_code = 'RESSD - DETACHED SINGLE DWELLING' AND (zoning LIKE 'R1%' OR zoning LIKE 'R2 %' OR zoning LIKE 'RMFS %')"
def fetch(offset):
 dest=r/f'detached-{offset:06}.json'
 if dest.exists(): return
 params={'$select':'roll_number,neighbourhood_area,zoning,geometry','$where':where,'$limit':'10000','$offset':str(offset),'$order':'roll_number ASC'}
 subprocess.run(['curl','-qfsSL','--retry','1','--max-time','70',endpoint+'?'+urllib.parse.urlencode(params),'-o',dest],check=True)
 print(dest.name,dest.stat().st_size,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as e: list(e.map(fetch,range(0,200000,10000)))
