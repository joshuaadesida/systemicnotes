"""Aggregate official Winnipeg data. Run from any directory with the two paths below."""
import argparse
from collections import Counter
import csv
import json
from pathlib import Path
import re
from zipfile import ZipFile

from pyproj import Transformer
import shapely
from shapely.geometry import shape, mapping

ASSESSMENT_ALIASES = {
    "CENTRAL RIVER HGTS": "Central River Heights",
    "INKSTER INDUSTRIAL": "Inkster Industrial Park",
    "LEILA-MCPHILLIPS TRI": "Leila-McPhillips Triangle",
    "N INKSTER INDUSTRIAL": "North Inkster Industrial",
    "ST B INDUSTRIAL PARK": "St. Boniface Industrial Park",
    "ST VITAL PERIMETER S": "St. Vital Perimeter South",
    "W K INDUSTRIAL": "West Kildonan Industrial",
}
PERMIT_ALIASES = {"LELIA NORTH": "Leila North"}
ZONING_R1 = {"R1S", "R1M", "R1L", "R1E"}
CANDIDATE_ZONING = ZONING_R1 | {"R2", "RMFS"}
RES_USES = set("RESSD CNAPT RESSS CNRES RESMC RESRH RESAP RESDU RESSU RESMA CNCMP RESGC RESMU RESAM RESTR RESMB RESRM RESMH".split())
RAPID_FREQUENT = {"BLUE", "FX2", "FX3", "FX4", "F5", "F6", "F7", "F8", "F9"}
to_m = Transformer.from_crs("EPSG:4326", "EPSG:26914", always_xy=True)
to_degrees = Transformer.from_crs("EPSG:26914", "EPSG:4326", always_xy=True)


def key(value):
    return re.sub(r"[^a-z0-9]", "", (value or "").casefold())


def read(root, name):
    return json.loads((root / name).read_text())


def route_coverage(root):
    def rows(bundle, name):
        return csv.DictReader(line.decode("utf-8-sig") for line in bundle.open(name + ".txt"))

    with ZipFile(root / "transit.zip") as bundle:
        feed = next(rows(bundle, "feed_info"))
        active = {row["route_id"] for row in rows(bundle, "routes") if row["route_id"] in RAPID_FREQUENT}
        trips = {row["trip_id"] for row in rows(bundle, "trips") if row["route_id"] in active}
        stop_ids = {row["stop_id"] for row in rows(bundle, "stop_times") if row["trip_id"] in trips
                    and (row.get("pickup_type") != "1" or row.get("drop_off_type") != "1")}
        stops = [shapely.Point(*to_m.transform(float(row["stop_lon"]), float(row["stop_lat"])))
                 for row in rows(bundle, "stops") if row["stop_id"] in stop_ids]
    assert active == RAPID_FREQUENT and len(stops) > 150
    print(f"{len(stops)} eligible transit stop IDs on {len(active)} lines")
    return shapely.union_all(shapely.buffer(stops, 800, quad_segs=12)), feed, len(active)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--date", required=True)
    args = parser.parse_args()
    root = args.input
    source = read(root, "neighbourhoods.geojson")["features"]
    records = {}
    features = []
    census = read(root, "census-values.json") if (root / "census-values.json").exists() else {}
    for f in source:
        name = f["properties"]["name"]
        assert key(name) not in records
        polygon = shapely.make_valid(shape(f["geometry"]))
        if polygon.geom_type == "GeometryCollection":
            polygon = shapely.union_all([item for item in polygon.geoms if item.geom_type in {"Polygon", "MultiPolygon"}])
        assert not polygon.is_empty and polygon.geom_type in {"Polygon", "MultiPolygon"}
        metre_geometry = shapely.transform(polygon, to_m.transform, interleaved=False)
        data = dict(id=str(f["properties"]["id"]), name=name, areaHa=round(metre_geometry.area / 10000, 1),
                    r1=0, residential=0, candidates=0, mappedCandidates=0, near=0, created=0, lost=0, permits=0,
                    history=[0] * 7, census=census.get(key(name)))
        records[key(name)] = data
        features.append(dict(type="Feature", geometry=mapping(shapely.set_precision(polygon, 0.000001)), properties=data))

    assessment = Counter()
    unknown_rolls = Counter()
    for row in read(root, "assessment-types.json"):
        code = row.get("property_use_code", "").partition(" ")[0]
        zoning = row.get("zoning", "").partition(" ")[0]
        name = row.get("neighbourhood_area", "")
        match = records.get(key(ASSESSMENT_ALIASES.get(name, name)))
        if code in RES_USES and zoning and match:
            count = int(row["count"])
            match["residential"] += count
            match["r1"] += count if zoning in ZONING_R1 else 0
        if code == "RESSD" and zoning in CANDIDATE_ZONING:
            assessment[name] += int(row["count"])

    buffered, feed, route_count = route_coverage(root)
    shapely.prepare(buffered)
    rolls_seen = set()
    detail = Counter()
    for page in sorted(root.glob("detached-*.json")):
        for row in json.loads(page.read_text()):
            if row["zoning"].partition(" ")[0] not in CANDIDATE_ZONING:
                continue
            assert row["roll_number"] not in rolls_seen, "Duplicate assessment roll"
            rolls_seen.add(row["roll_number"])
            name = row.get("neighbourhood_area", "")
            detail[name] += 1
            match = records.get(key(ASSESSMENT_ALIASES.get(name, name)))
            if not match:
                unknown_rolls[name] += 1
                continue
            match["candidates"] += 1
            if row.get("geometry"):
                point = shape(row["geometry"]).representative_point()
                if not point.is_empty and -98 < point.x < -96 and 49 < point.y < 51:
                    match["mappedCandidates"] += 1
                    match["near"] += int(buffered.covers(shapely.Point(*to_m.transform(point.x, point.y))))
    assert assessment == detail, f"Candidate detail totals disagree with grouped counts {assessment-detail} {detail-assessment}"

    missing_permits = Counter()
    permit_keys = set()
    for row in read(root, "permits.json"):
        name = row.get("neighbourhood_name", "")
        normal = key(PERMIT_ALIASES.get(name, name))
        match = records.get(normal)
        created, lost = int(row.get("created") or 0), int(row.get("lost") or 0)
        if not match:
            missing_permits[name] += created - lost
            continue
        source_key = (name, row.get("neighbourhood_number"), row["year"])
        assert source_key not in permit_keys, f"Duplicate grouped permit records for {source_key}"
        permit_keys.add(source_key)
        match["created"] += created
        match["lost"] += lost
        match["permits"] += int(row["permits"])
        match["history"][int(row["year"]) - 2019] += created - lost
    assert len(rolls_seen) == sum(n["candidates"] for n in records.values()) + sum(unknown_rolls.values())
    assert all(0 <= n["near"] <= n["mappedCandidates"] <= n["candidates"] and n["r1"] <= n["residential"] for n in records.values())
    assert all(sum(n["history"]) == n["created"] - n["lost"] for n in records.values())

    buffer_geo = mapping(shapely.set_precision(shapely.transform(buffered.simplify(15, preserve_topology=True), to_degrees.transform, interleaved=False), 0.000001))
    start, end = feed["feed_start_date"], feed["feed_end_date"]
    format_date = lambda x: "-".join((x[:4],x[4:6],x[6:]))
    metadata = dict(retrieved=args.date, transitPeriod=f"{format_date(start)} to {format_date(end)}", transitRoutes=route_count,
                    permitsStart=2019, permitsEnd=2025, censusProfiles=sum(n["census"] is not None for n in records.values()),
                    assessmentUnmatched=sum(unknown_rolls.values()), permitNetUnmatched=sum(missing_permits.values()))
    snapshot = dict(type="FeatureCollection", features=features, metadata=metadata,
                    transit=dict(type="FeatureCollection", features=[dict(type="Feature", geometry=buffer_geo, properties={})]))
    args.output.write_text(json.dumps(snapshot, ensure_ascii=False, separators=(",", ":"), allow_nan=False))
    print(metadata)
    print("Unmatched assessment and permits:", unknown_rolls, missing_permits)
    print({k: sum(n[k] for n in records.values()) for k in ("candidates","mappedCandidates","near","created","lost","permits")})


if __name__ == "__main__":
    main()
