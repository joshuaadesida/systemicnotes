import subprocess, pathlib, urllib.parse, concurrent.futures
import sys
r = pathlib.Path(sys.argv[1])
r.mkdir(parents=True, exist_ok=True)
params={
 'neighbourhoods.geojson':('8k6x-xxsy.geojson',{'$limit':'500','$order':'id'}),
 'assessment-profile.json':('d4mq-wa44.json',{'$select':'building_type,property_use_code,count(*) as count','$group':'building_type,property_use_code','$order':'count desc','$limit':'45'}),
 'assessment-zones.json':('d4mq-wa44.json',{'$select':'zoning,count(*) as count','$group':'zoning','$order':'count desc','$limit':'90'}),
 'assessment-types.json':('d4mq-wa44.json',{'$select':'neighbourhood_area,building_type,zoning,property_use_code,count(*) as count','$group':'neighbourhood_area,building_type,zoning,property_use_code','$limit':'20000'}),
 'permits-profile.json':('it4w-cpf4.json',{'$select':'permit_group,status,count(*) as count','$group':'permit_group,status','$where':"issue_date between '2019-01-01' and '2025-12-31T23:59:59'",'$order':'count desc','$limit':'40'}),
 'permits.json':('it4w-cpf4.json',{'$select':'neighbourhood_number,neighbourhood_name,date_extract_y(issue_date) as year,count(*) as permits,sum(dwelling_units_created) as created,sum(dwelling_units_lost) as lost','$group':'neighbourhood_number,neighbourhood_name,date_extract_y(issue_date)','$where':"issue_date >= '2019-01-01' and issue_date < '2026-01-01' and (dwelling_units_created > 0 or dwelling_units_lost > 0)",'$limit':'5000'}),
 'zoning-sample.geojson':('dxrp-w6re.geojson',{'$limit':'3'}),
}
def fetch(entry):
 name,(url,params)=entry
 subprocess.run(['curl','-qfsSL','--max-time','45','https://data.winnipeg.ca/resource/'+url+'?'+urllib.parse.urlencode(params),'-o',r/name],check=True)
 print(name,(r/name).stat().st_size)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as e:
 for future in [e.submit(fetch, entry) for entry in params.items()]:
  future.result()
