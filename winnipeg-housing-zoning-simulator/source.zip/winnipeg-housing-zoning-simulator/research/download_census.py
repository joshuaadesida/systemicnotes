import concurrent.futures, html, json, re, subprocess
from pathlib import Path
from urllib.parse import quote, unquote

import sys
root = Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=True)
subprocess.run(["curl", "-qfsSL", "https://legacy.winnipeg.ca/census/2021/", "-o", str(root / "census-index.html")], check=True)
output = root / "census-pdfs"
output.mkdir(exist_ok=True)
host = "https://legacy.winnipeg.ca"
clusters = re.findall(r'href="(/census/2021/Community Areas/[^"]+/default\.asp)"', (root / 'census-index.html').read_text(), re.I)

def get(url, destination=None):
    args = ['curl', '-qfsSL', '--max-time', '22', '--retry', '1', url]
    if destination:
        if destination.exists() and destination.stat().st_size > 10000:
            return ''
        args.extend(['-o', str(destination)])
    run = subprocess.run(args, capture_output=True)
    if run.returncode != 0:
        print('Unavailable:', url, flush=True)
        return ''
    return run.stdout.decode(errors='replace')

def links(cluster):
    page = get(host + quote(html.unescape(cluster), safe="/-_."))
    return re.findall(r"window.open\('(/Census/2021/Community Areas/[^']+?\.pdf)'\)", page, re.I)

with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
    paths = sorted(set(path for group in pool.map(links, clusters) for path in group))
    index = {str(i): [unquote(path.split('/')[-2]), host + quote(html.unescape(path),safe="/-_.")] for i,path in enumerate(paths)}
    (output / 'index.json').write_text(json.dumps(index))
    print(len(clusters), len(index), flush=True)
    list(pool.map(lambda item: get(item[1][1], output / (item[0]+'.pdf')), index.items()))
