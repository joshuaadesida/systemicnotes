"""Extract published rows while preserving unavailable and suppressed values."""
import argparse
import json
from pathlib import Path
import re

import pymupdf
from build_snapshot import key

ALIASES = {
    "Echange District": "Exchange District",
    "West Aleander": "West Alexander",
    "Logan-C.P.R": "Logan-C.P.R.",
    "Windsor Park": "Windsor Park",
}


def first_field(line, convert):
    fields = re.split(r"\s{2,}", line.strip())
    value = fields[1].replace(",", "") if len(fields) > 1 else ""
    return convert(value)


def rate(line, contains):
    fields = re.split(r"\s{2,}", line.strip())
    if len(fields) < 5 or fields[0].lower() != contains:
        return None
    if not re.fullmatch(r"[\d,.]+%", fields[2]):
        return None
    value = float(fields[2][:-1])
    return value if 0 <= value <= 100 else None


def parse_profile(path):
    with pymupdf.open(path) as doc:
        overview = doc[1].get_text(sort=True)
        income = doc[-4].get_text(sort=True)
        housing = doc[-2].get_text(sort=True)
    population = None
    for line in overview.splitlines():
        if line.strip().startswith("2021 CENSUS"):
            population = first_field(line, lambda n: int(n) if n.isdigit() else None)
            break
    median = None
    for line in income.splitlines():
        if line.strip().lower().startswith("median household income"):
            median = first_field(line, lambda n: int(n[1:]) if re.fullmatch(r"\$\d+", n) else None)
            break
    tenant = None
    burden = None
    housing_lines = housing.splitlines()
    for i, line in enumerate(housing_lines):
        if re.match(r"\s*Rented\s{2,}", line):
            tenant = rate(line, "rented")
        if re.search(r"% of tenant households spending 30% or more", line, re.I):
            for following in housing_lines[i:i+4]:
                if re.match(r"\s*shelter costs\s{2,}", following, re.I):
                    burden = rate(following, "shelter costs")
                    break
            if burden is not None:
                break

    return dict(population=population, income=median, tenantShare=tenant, rentBurden=burden)


def main():
    cli = argparse.ArgumentParser()
    cli.add_argument("pdf_folder", type=Path)
    cli.add_argument("output", type=Path)
    args = cli.parse_args()
    profiles = {}
    for i, (name, source) in json.loads((args.pdf_folder / "index.json").read_text()).items():
        path = args.pdf_folder / (i+".pdf")
        if not path.exists():
            continue
        normal = key(ALIASES.get(name, name))
        row = parse_profile(path)
        if normal in profiles:
            assert row == {k: profiles[normal][k] for k in row}, name
            continue
        profiles[normal] = dict(**row, source=source)
    assert profiles["westbroadway"]["rentBurden"] == 43.9
    assert profiles["westbroadway"]["tenantShare"] == 92.6
    assert profiles["westbroadway"]["income"] == 36000
    assert profiles["westbroadway"]["population"] == 5590
    args.output.write_text(json.dumps(profiles, ensure_ascii=False))
    print(f"Parsed {len(profiles)} profiles, {sum(n['rentBurden'] is not None for n in profiles.values())} rent-burden rows")


if __name__ == "__main__":
    main()
